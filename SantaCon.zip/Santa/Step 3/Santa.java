import Santa.SantaState;

//import com.sun.org.apache.xml.internal.security.utils.HelperNodeList;


public class Santa implements Runnable {

	enum SantaState {SLEEPING, READY_FOR_CHRISTMAS, WOKEN_UP_BY_ELVES, WOKEN_UP_BY_REINDEER};
	private SantaState state;
	private boolean kill;
	private SantaScenario scenario;

	public Santa(SantaScenario scenario) 
	{
		this.state = SantaState.SLEEPING;
		this.scenario = scenario;
		setKill(false);
	}
	// Setters and getters for kill
	public boolean isKill() 
	{
		return kill;
	}
	public void setKill(boolean kill) 
	{
			this.kill = kill;
	}
	public SantaState getState()
	{
		return state;
	}
	public void ElvesWakeUpSanta()
	{
		this.state = SantaState.WOKEN_UP_BY_ELVES;
	}
	public void setState(SantaState state) {
		this.state = state;
	}
	public void sKill(boolean santa)
	{
		this.kill = santa;
		System.out.println("Santa killed \n");
	}


	@Override
	public void run() {
		while(this.kill == false) {
			// wait a day...
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			switch(state) {
			case SLEEPING: // if sleeping, continue to sleep
				// Thread issue with elves, only one santa so santa class will handle elves state
				int elfintroub = 0;
				int stop = 0;
		  		for(Elf elf :scenario.elves)
				{
		  			if(elfintroub == 3)
		  			{
		  		  	for(Elf elf2 :scenario.elves)
		  		  	{
		  		  		// Make sure only 3 elves can go to door
		  		  		if(elf2.getState() == Elf.ElfState.TROUBLE && stop <= 2)
		  		  		{
		  		  			elf2.setState(Elf.ElfState.AT_SANTAS_DOOR);
		  		  			stop += 1;
		  		  		}
		  		  	}
		  		  	// Three are at door, wake up santa
		  		  		ElvesWakeUpSanta();
		  			}
		 			if(elf.getState() == Elf.ElfState.TROUBLE)
					{
						elfintroub += 1;
					}
				}
				
				break;
			case WOKEN_UP_BY_ELVES:
			for(Elf elf :scenario.elves)
			{
				if(elf.getState() == Elf.ElfState.AT_SANTAS_DOOR)
				{
					elf.setState(Elf.ElfState.WORKING);
				}
				scenario.setElvesintrouble(0);
				state = SantaState.SLEEPING;
			}
				break;
			case WOKEN_UP_BY_REINDEER:

				break;
			case READY_FOR_CHRISTMAS: // nothing more to be done
				break;
			}
		}
	}


	/**
	 * Report about my state
	 */
	public void report() {
		System.out.println("Santa : " + state);
	}


}
